


class LectorEntrada{

private:

protected:
    char key;
public:

    LectorEntrada();

    int funcionEspecial();

    void asignarTecla(char _key);
    
    bool teclaMarcada();



    ~LectorEntrada();
};